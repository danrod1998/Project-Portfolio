#install package and load library (lines 2-12)
pkgs <- c("Rtsne","gamlss","fitdistrplus","mice","tidyverse","Amelia","missForest","caret","Rtsne","readr","dplyr","cluster")
install.packages(pkgs)
library(gamlss)
library(gamlss.dist)
library(tidyverse)
library(mice)
library(Amelia)
library(missForest)
library(caret)
library(Rtsne)
library(fitdistrplus)
library(readr)
library(dplyr)
library(cluster)
#import csv into variable as dataframe
dat <- read.csv('C://Users//danie//Downloads//googleplaystore.csv',header=T,na.strings=c(""))
#graph and compare missing values to total values in current dataframe
missmap(dat, main = "Missing values vs observed")
sum(is.na(dat))
summary(dat)
#take sample of dataframe to alleviate load on algorithm performance
dat<-dat[1:1000,]
#convert categorical variable values into indiviual numerical dummy variables
dmy <- dummyVars(" ~ .", data = dat, fullRank = T)
#initiate variable with newly modified dataframe
dat_transformed <- data.frame(predict(dmy, newdata = dat))
#use random forest algorithm to imputate missing values
iris.imp <- missForest(dat_transformed)
#transfer modified dataframe into new variable
dor<-iris.imp$ximp
#convert dataframe to tibble for easier modification
df <- as_tibble(dor)
#remove duplicate rows/values
df <- unique(df)





#find distribution model that best fits dataframe (tibble)
descdist(dor$Rating, discrete = FALSE)

#compare distribution model AIC values to confirm findings (43-50)
fit.weibull <- fitdist(dor$Rating, "weibull")
fit.norm <- fitdist(dor$Rating, "norm")
fit.lnorm <- fitdist(dor$Rating, "lnorm")
fit.gamma <- fitdist(dor$Rating, "gamma")
fit.lnorm$aic
fit.weibull$aic
fit.norm$aic
fit.gamma$aic
#fit data to chosen model (weibull)
plot(fit.weibull)
summary(fit.weibull)

#select dependent and independent variables for regression modeling
data<-  df %>% select(Type.Paid,Installs.5.000.000.)

#model data using probit regression
model <- glm(Type.Paid ~.,family=binomial(link='probit'),data=data)
#compare usage of different variables and their effects on AIC
slm1 <- step(model)
#anova analysis of model data (p-values, etc.)
anova(model, test="Chisq")
#analysis of model data (p-values, AIC, r-values)
summary(model)
#initiate fit variable value as regression prediction
fit <- predict(model,na.omit(data),type='response')
#predict on data in model
fitted.results <- ifelse(fit > 0.5,2,1)
#compare predicted/fitted results to actual values 
misclassification_error <- mean(fitted.results != data$Installs.5.000.000.)
#retrieve model prediction accuracy
1 - misclassification_error

#alternate variable selection
model <- glm(Installs.5.000.000. ~.,family=binomial(link='probit'),data=data)

#compare usage of different variables and their effects on AIC
slm1 <- step(model)
#anova analysis of model data (p-values, etc.)
anova(model, test="Chisq")
#analysis of model data (p-values, AIC, r-values)
summary(model)
#initiate fit variable value as regression prediction
fit <- predict(model,na.omit(data),type='response')
#predict on data in model
fitted.results <- ifelse(fit > 0.5,2,1)
#compare predicted/fitted results to actual values 
misclassification_error <- mean(fitted.results != data$Installs.5.000.000.)
#retrieve model prediction accuracy
1 - misclassification_error




#measure gower distances between variables (optimal for situations involving categorical data)
gower_dist <- daisy(df, metric = "gower")
#initialize gower_mat variable with matrix of distances
gower_mat <- as.matrix(gower_dist)

#algorithm below (lines 98-106) determine optimal number of clusters (k-value) to create
sil_width <- c(NA)
for(i in 2:8){  
  pam_fit <- pam(gower_dist, diss = TRUE, k = i)  
  sil_width[i] <- pam_fit$silinfo$avg.width  
}
#plots graph of possible k-values; highest value considered as k-value 
#for k-medoids/k-medians algorithm (105-108)
plot(1:8, sil_width,
     xlab = "Number of clusters",
     ylab = "Silhouette Width")
lines(1:8, sil_width)

#run k-medoids clustering algorithms on 8 clusters (110-117)
k <- 8
pam_fit <- pam(gower_dist, diss = TRUE, k)
#pam_results stores dataframe of clusters and their respective values
#(115-119)
pam_results <- df %>%
  mutate(cluster = pam_fit$clustering) %>%
  group_by(cluster) %>%
  do(the_summary = summary(.))
#retrieve dataframe to analyze clusters
pam_results$the_summary

#visualize clusters using Rtsne library (123-129)
tsne_obj <- Rtsne(gower_dist, is_distance = TRUE)
tsne_data <- tsne_obj$Y %>%
  data.frame() %>%
  setNames(c("X", "Y")) %>%
  mutate(cluster = factor(pam_fit$clustering))
#compare cluster sizes

ggplot(aes(x = X, y = Y), data = tsne_data) +
  geom_point(aes(color = cluster))
#plot graph and name each cluster according to their characteristics
#relabel data graph (122-130)
tsne2<-tsne_data
tsne2$cluster <- gsub('1', 'Art_and_Design_Free_100000', tsne2$cluster)
tsne2$cluster <- gsub('2', 'Business_Free_5000000', tsne2$cluster)
tsne2$cluster <- gsub('3', 'Comm_Free_10000000', tsne2$cluster)
tsne2$cluster <- gsub('4', 'Auto_And_Vehicles_Free_100000', tsne2$cluster)
tsne2$cluster <- gsub('5', 'Education_Free_1000000', tsne2$cluster)
tsne2$cluster <- gsub('6', 'Beauty_Free_10000', tsne2$cluster)
tsne2$cluster <- gsub('7', 'Entertainment_Free_1000000', tsne2$cluster)
tsne2$cluster <- gsub('8', 'Dating_Free_100000', tsne2$cluster)
#transform original dataset
tsne_data <-tsne2

#compare cluster sizes

ggplot(aes(x = X, y = Y), data = tsne_data) +
  geom_point(aes(color = cluster))


